export enum ConstsUser {
  PASSWORD_MIN_CHAR = 4,
}
