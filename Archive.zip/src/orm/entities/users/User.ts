import bcrypt from 'bcryptjs';import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, BaseEntity } from 'typeorm';
import { Role, Language } from './types';
import { randomBytes, createHmac } from 'crypto';
import { createJwtToken } from 'utils/createJwtToken';
import jwt from 'jsonwebtoken';

@Entity('users')
export class User extends BaseEntity{
  @PrimaryGeneratedColumn('increment') 
  id: number;

  @Column({
    type: 'varchar', 
    unique: true,
  })
  email: string;

  @Column({
    type: 'varchar', 
  })
  password: string;

  @Column({
    type: 'varchar', 
    nullable: true,
    unique: true,
  })
  username: string;

  @Column({
    type: 'varchar', 
    nullable: true,
  })
  name: string;

  @Column({
    type: 'varchar', 
    default: 'STANDARD' as Role,
    length: 30,
  })
  role: string;

  @Column({
    type: 'varchar', 
    default: 'en-US' as Language,
    length: 15,
  })
  language: string;

  @Column({
    type: 'varchar', 
    nullable: true,
  })
  otp: string;

  @Column({
    nullable: true,
    type: 'timestamp',
  })
  otp_expiry: Date;

  @Column({
    default: false,
  })
  isVerified: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ type: 'varchar', nullable: true })
  resetPasswordToken: string;

  @Column({ type: 'timestamp', nullable: true })
  resetPasswordExpires: Date;

  setLanguage(language: Language) {
    this.language = language;
  }

  hashPassword() {
    this.password = bcrypt.hashSync(this.password, 8);
  }


  checkIfPasswordMatch(unencryptedPassword: string) {
    return bcrypt.compareSync(unencryptedPassword, this.password);
  }

async generatePasswordResetToken() {
    // Generate a random token
    const resetToken = randomBytes(20).toString('hex');

    // Create a JWT with the reset token and an expiration of 1 hour
    const jwtToken = jwt.sign({ resetToken }, process.env.JWT_SECRET, { expiresIn: '1h' });

    // Save the JWT as the resetPasswordToken
    this.resetPasswordToken = jwtToken;
    this.resetPasswordExpires = new Date(Date.now() + 1 * 60 * 60 * 1000);

    // Save the user
    await this.save();

    return jwtToken;
}

  
  
}
