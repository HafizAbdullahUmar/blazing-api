import { Request, Response } from 'express';

import  {makeEntryActor}  from '../../dfx/service/actor-locator';

export const getEntry = async (req: Request, res: Response) => { 
    const entryId = req.params.id; 

    const entry = await fetchEntryFromDatabase(entryId); 
    console.log("got this entry", entry, entryId)
    if (!entry) {
        return res.status(404).json({ error: 'Entry not found' });
    }

    return res.json(entry);
};

const fetchEntryFromDatabase = async (entryId: string) => {
    const entryActor = makeEntryActor({})
    const entry = await entryActor.getEntryMeta(entryId)
    console.log(entry)
    return entry;
};